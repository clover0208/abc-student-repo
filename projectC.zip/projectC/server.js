const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);
let infos=[];
app.use(express.static('public'))
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
  console.log('a user connected',socket.id);

  socket.on('disconnect', () => {
    console.log('user disconnected',socket.id);
  });

  socket.on("message",(data)=>{
    console.log(data);
    io.emit("incoming",data);
  });

  socket.on("message2",(data)=>{
    //console.log(data);
    io.emit("incoming",data);
  });

  socket.on("position",(data)=>{
    console.log(data);
    infos.push(data);
    //io.emit("Position",data);
    io.emit("Position",infos);

    //push datas into the array here?maybe

  });

});

server.listen(3000, () => {
  console.log('listening on *:3000');
});
