let socket=io();

let canvas = document.getElementById("myCanvas");
let ctx = canvas.getContext("2d");
let x = canvas.width/2;
let y = canvas.height-30;

let x0=canvas.width/2;
let y0=canvas.height/2;
let d=0;

let rightPressed=false;
let leftPressed=false;
let upPressed=false;
let downPressed=false;

document.addEventListener("keydown", keyDown, false);
document.addEventListener("keyup", keyUp, false);

// document.addEventListener("keydown",()=>{
//   console.log("KEY DOWN");
// });






function mapRange (value, a, b, c, d) {
    // first map value from (a..b) to (0..1)
    value = (value - a) / (b - a);
    // then map it from (0..1) to (c..d) and return it
    return c + value * (d - c);
}

function keyDown(e){
  if(e.key == "Right" || e.key == "ArrowRight"){
    rightPressed=true;
  }

  else if(e.key == "Left" || e.key == "ArrowLeft"){
    leftPressed=true;
  }
  else if(e.key == "Up" || e.key == "ArrowUp"){
    upPressed=true;
  }
  else if(e.key == "Down" || e.key == "ArrowDown"){
    downPressed=true;
  }

}

function keyUp(e){
  if(e.key == "Right" || e.key == "ArrowRight"){
    rightPressed=false;
  }

  else if(e.key == "Left" || e.key == "ArrowLeft"){
    leftPressed=false;
  }

  else if(e.key == "Up" || e.key == "ArrowUp"){
    upPressed=false;
  }
  else if(e.key == "Down" || e.key == "ArrowDown"){
    downPressed=false;
  }
}

function drawBall(xx,yy) {
    ctx.beginPath();
    ctx.arc(xx, yy, 10, 0, Math.PI*2);
    ctx.fillStyle = "#0095DD";
    ctx.fill();
    ctx.closePath();
}


function draw() {

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBall(x,y);
    if(leftPressed){
      x-=5;
    }
    else if(rightPressed){
      x+=5;
    }

    else if(upPressed){
      y-=5;
    }

    else if(downPressed){
      y+=5;
    }
    let temp_d=(x-x0)**2+(y-y0)**2;
    d=Math.sqrt(temp_d);
    //ring.volume=mapRange(d,0,500,1,0);
    //console.log(d);
    //map(d,0,1400,0,1)
    // if(x>canvas.width || x<0){
    //   dx*=-1;
    // }
    // if(y>canvas.height || y<0){
    //   dy*=-1;
    // }
    //x += dx;
    //y += dy;
}

setInterval(draw, 10);

document.addEventListener("keyup",()=>{
  console.log("KEY UP");
  let data={id:socket.id,x:x,y:y}
  socket.emit('position',data);
});

socket.on("Position",(data)=>{
  console.log("!!!!!*********");
  console.log(data);
  x=data.x;
  y=data.y;
  for(let i=0;i<data.length;i++){

  }
  //r.value=data.red;
  // g.value=data.green;
  // b.value=data.blue;
  //document.body.style.backgroundColor = "rgb("+data.red+","+g.value+","+b.value+")";


})
